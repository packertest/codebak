#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <string.h>

#define SECTION_NAME ".new_section"
#define ALIGNMENT_SIZE 0x1000 // Align data to page size

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <exe_file>\n", argv[0]);
        return 1;
    }

    char *exeFileName = argv[1];

    // Open the EXE file for reading and writing
    HANDLE hFile = CreateFile(exeFileName, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE) {
        printf("Error opening file: %s\n", exeFileName);
        return 1;
    }

    // Get the file size
    DWORD fileSize = GetFileSize(hFile, NULL);
    if (fileSize == INVALID_FILE_SIZE) {
        printf("Error getting file size\n");
        CloseHandle(hFile);
        return 1;
    }

    // Read the DOS header
    IMAGE_DOS_HEADER dosHeader;
    DWORD bytesRead;
    if (!ReadFile(hFile, &dosHeader, sizeof(IMAGE_DOS_HEADER), &bytesRead, NULL)) {
        printf("Error reading DOS header\n");
        CloseHandle(hFile);
        return 1;
    }

    // Check if this is a valid DOS file
    if (dosHeader.e_magic != IMAGE_DOS_SIGNATURE) {
        printf("Not a valid DOS file\n");
        CloseHandle(hFile);
        return 1;
    }

    // Seek to the PE header
    if (SetFilePointer(hFile, dosHeader.e_lfanew, NULL, FILE_BEGIN) == INVALID_SET_FILE_POINTER) {
        printf("Error seeking to PE header\n");
        CloseHandle(hFile);
        return 1;
    }

    // Read the PE header
    IMAGE_NT_HEADERS ntHeader;
    if (!ReadFile(hFile, &ntHeader, sizeof(IMAGE_NT_HEADERS), &bytesRead, NULL)) {
        printf("Error reading PE header\n");
        CloseHandle(hFile);
        return 1;
    }

    // Check if this is a valid PE file
    if (ntHeader.Signature != IMAGE_NT_SIGNATURE) {
        printf("Not a valid PE file\n");
        CloseHandle(hFile);
        return 1;
    }

    // Calculate the size of new section table
    DWORD newSectionSize = sizeof(IMAGE_SECTION_HEADER);

    // Increase the size of image
    ntHeader.FileHeader.SizeOfOptionalHeader += newSectionSize;
    ntHeader.OptionalHeader.SizeOfImage += newSectionSize;

    // Calculate the offset of new section table
    DWORD newSectionOffset = dosHeader.e_lfanew + sizeof(DWORD) + sizeof(IMAGE_FILE_HEADER) + ntHeader.FileHeader.SizeOfOptionalHeader;

    // Seek to new section table
    if (SetFilePointer(hFile, newSectionOffset, NULL, FILE_BEGIN) == INVALID_SET_FILE_POINTER) {
        printf("Error seeking to new section table\n");
        CloseHandle(hFile);
        return 1;
    }

    // Create new section
    IMAGE_SECTION_HEADER newSection = { 0 };
    strcpy(newSection.Name, SECTION_NAME);
    newSection.Misc.VirtualSize = ALIGNMENT_SIZE; // Align data to page size
    newSection.VirtualAddress = ntHeader.OptionalHeader.SizeOfImage; // Place the new section at the end
    newSection.SizeOfRawData = ALIGNMENT_SIZE; // Size of new section data
    newSection.PointerToRawData = fileSize; // Offset of new section data

    // Write new section to file
    if (!WriteFile(hFile, &newSection, sizeof(IMAGE_SECTION_HEADER), &bytesRead, NULL)) {
        printf("Error writing new section to file\n");
        CloseHandle(hFile);
        return 1;
    }

    // Update the number of sections
    ntHeader.FileHeader.NumberOfSections++;

    // Update the PE header
    if (SetFilePointer(hFile, dosHeader.e_lfanew, NULL, FILE_BEGIN) == INVALID_SET_FILE_POINTER) {
        printf("Error seeking back to PE header\n");
        CloseHandle(hFile);
        return 1;
    }

    if (!WriteFile(hFile, &ntHeader, sizeof(IMAGE_NT_HEADERS), &bytesRead, NULL)) {
        printf("Error writing updated PE header to file\n");
        CloseHandle(hFile);
        return 1;
    }

    // Write data to the new section
    SetFilePointer(hFile, 0, NULL, FILE_END); // Seek to the end of the file
    char *data = "This is new data in the new section.\n";
    DWORD bytesWritten;
    if (!WriteFile(hFile, data, strlen(data), &bytesWritten, NULL)) {
        printf("Error writing data to new section\n");
        CloseHandle(hFile);
        return 1;
    }

    printf("New section added and data written successfully\n");

    // Close the file
    CloseHandle(hFile);

    // Reopen the file for reading the added section
    hFile = CreateFile(exeFileName, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE) {
        printf("Error opening file for reading: %s\n", exeFileName);
        return 1;
    }

    // Seek to the beginning of the new section
    DWORD newSectionStart = fileSize + sizeof(IMAGE_SECTION_HEADER);
    if (SetFilePointer(hFile, newSectionStart, NULL, FILE_BEGIN) == INVALID_SET_FILE_POINTER) {
        printf("Error seeking to new section start\n");
        CloseHandle(hFile);
        return 1;
    }

    // Read data from the new section
    char buffer[ALIGNMENT_SIZE + 1]; // Allocate a buffer to hold the data
    if (!ReadFile(hFile, buffer, ALIGNMENT_SIZE, &bytesRead, NULL)) {
        printf("Error reading data from new section\n");
        CloseHandle(hFile);
        return 1;
    }
    buffer[bytesRead] = '\0'; // Null-terminate the buffer

    printf("Data read from new section:\n%s\n", buffer);

    // Close the file
    CloseHandle(hFile);

    return 0;
}

/////////////////////////////////////

#include <stdio.h>
#include <windows.h>

int main() {
    // 获取当前可执行文件的句柄
    HMODULE hModule = GetModuleHandle(NULL);
    if (hModule == NULL) {
        printf("Error getting module handle\n");
        return 1;
    }

    // 获取可执行文件的路径
    char exePath[MAX_PATH];
    if (!GetModuleFileName(hModule, exePath, MAX_PATH)) {
        printf("Error getting module file name\n");
        return 1;
    }

    // 打开可执行文件
    HANDLE hFile = CreateFile(exePath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile == INVALID_HANDLE_VALUE) {
        printf("Error opening file: %s\n", exePath);
        return 1;
    }

    // 获取PE头的位置
    DWORD dwPEOffset;
    if (!ReadFile(hFile, &dwPEOffset, sizeof(dwPEOffset), NULL, NULL)) {
        printf("Error reading PE offset\n");
        CloseHandle(hFile);
        return 1;
    }

    // 移动文件指针到PE头的位置
    if (SetFilePointer(hFile, dwPEOffset, NULL, FILE_BEGIN) == INVALID_SET_FILE_POINTER) {
        printf("Error setting file pointer to PE header\n");
        CloseHandle(hFile);
        return 1;
    }

    // 读取PE头
    IMAGE_NT_HEADERS ntHeader;
    if (!ReadFile(hFile, &ntHeader, sizeof(IMAGE_NT_HEADERS), NULL, NULL)) {
        printf("Error reading PE header\n");
        CloseHandle(hFile);
        return 1;
    }

    // 计算节表的位置
    DWORD dwSectionTableOffset = dwPEOffset + sizeof(DWORD) + sizeof(IMAGE_FILE_HEADER) + ntHeader.FileHeader.SizeOfOptionalHeader;

    // 移动文件指针到节表的位置
    if (SetFilePointer(hFile, dwSectionTableOffset, NULL, FILE_BEGIN) == INVALID_SET_FILE_POINTER) {
        printf("Error setting file pointer to section table\n");
        CloseHandle(hFile);
        return 1;
    }

    // 读取节表数据
    IMAGE_SECTION_HEADER sectionHeader;
    for (int i = 0; i < ntHeader.FileHeader.NumberOfSections; ++i) {
        if (!ReadFile(hFile, &sectionHeader, sizeof(IMAGE_SECTION_HEADER), NULL, NULL)) {
            printf("Error reading section header\n");
            CloseHandle(hFile);
            return 1;
        }

        // 打印节表名称和数据
        printf("Section Name: %s\n", sectionHeader.Name);
        printf("Section Data: \n");

        // 移动文件指针到节的位置
        if (SetFilePointer(hFile, sectionHeader.PointerToRawData, NULL, FILE_BEGIN) == INVALID_SET_FILE_POINTER) {
            printf("Error setting file pointer to section data\n");
            CloseHandle(hFile);
            return 1;
        }

        // 读取并打印节数据
        char buffer[1024];
        DWORD dwBytesRead;
        if (!ReadFile(hFile, buffer, sectionHeader.SizeOfRawData, &dwBytesRead, NULL)) {
            printf("Error reading section data\n");
            CloseHandle(hFile);
            return 1;
        }
        buffer[dwBytesRead] = '\0';
        printf("%s\n", buffer);
    }

    // 关闭文件句柄
    CloseHandle(hFile);

    return 0;
}
